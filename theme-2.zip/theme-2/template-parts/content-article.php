
<p><?php  
the_content(); 
comments_template();
?></p>