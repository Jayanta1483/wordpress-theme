<footer class="mx-4 my-3">
<div id="sidebar" class="widgets-area"><?php dynamic_sidebar('Sidebar Area');  ?></div>
<?php wp_footer();   ?>
<p class="text-center">Jayanta Sarkar <?php echo comicpress_jayanta_copyright(); ?></p>
</div>
</footer>
</body>
</html>