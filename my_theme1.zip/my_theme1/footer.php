<footer class="footer text-center py-2 theme-bg-dark">
    <?php
    dynamic_sidebar('footer-1');


    ?>

    <p class="copyright"><a href="#">Jayanta Sarkar &#169; <?php echo date('Y'); ?></a></p>

</footer>

</div>


<!-- Bootstrap Javascript -->
<?php wp_footer(); ?>


</body>

</html>